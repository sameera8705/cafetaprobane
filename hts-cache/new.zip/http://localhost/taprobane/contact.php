<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Contact | Cafe Taprobane - The Fusion Haven</title>
<meta name="description" content="Cafe Taprobane serves true Sri Lankan food across Dubai, Sharjah and Kandy. Cafe, lounge, bar and party events.">
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Anton&family=Outfit:wght@400;500;600;700&family=Inter:wght@400;500;600&family=Dancing+Script:wght@600&family=Noto+Sans+Sinhala:wght@500;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="/taprobane/assets/css/style.css"></head><body>
<header class="top"><div class="in">
<nav class="L" aria-label="Main"><a href="/taprobane/index.php" >Home</a><a href="/taprobane/about.php" >About us</a><a href="/taprobane/branches.php" >Branches</a><a href="/taprobane/menu.php" >Menus</a></nav>
<a class="brand" href="/taprobane/index.php"><img class="" src="/taprobane/assets/img/TAPROBANE-LOGO.png" alt="Cafe Taprobane" onerror="this.onerror=null;this.src='/taprobane/assets/img/logo.png'"></a>
<nav class="R" aria-label="More"><a href="/taprobane/events.php" >Lounge &amp; Events</a><a href="/taprobane/news.php" >News</a><a href="/taprobane/careers.php" >Careers</a><a href="/taprobane/contact.php" class="on">Contact</a></nav>
<button class="burger" aria-label="Menu" aria-expanded="false"><span></span><span></span><span></span></button>
<div class="drawer"><a href="/taprobane/index.php" >Home</a><a href="/taprobane/about.php" >About us</a><a href="/taprobane/branches.php" >Branches</a><a href="/taprobane/menu.php" >Menus</a><a href="/taprobane/events.php" >Lounge &amp; Events</a><a href="/taprobane/news.php" >News</a><a href="/taprobane/careers.php" >Careers</a><a href="/taprobane/contact.php" class="on">Contact</a></div></div></header><main>
<section class="sec"><div class="wrap split"><div><div class="eyebrow">Contact</div><h1 style="font-size:clamp(2.2rem,5vw,3.4rem)">Talk to <span class="or">us</span></h1><p class="sub" style="margin-top:.8rem">Fastest way: WhatsApp or call. Or leave a message.</p>
<div class="btns"><a class="btn" href="https://wa.me/971504286739" target="_blank" rel="noopener">WhatsApp</a><a class="btn ghost" href="tel:+971504286739">Call +971504286739</a></div>
<div class="grid" style="margin-top:2rem"><div class="card"><h3>Al Nahda, Dubai</h3><p>050 428 6739 | 04 263 9079 | 04 296 7093</p></div><div class="card"><h3>International City (City Branch)</h3><p>054 235 3364 | 04 552 8708</p></div></div></div>
<form class="f card" method="post"><input type="hidden" name="t" value="b773b880577ddb3a8c0d32a9ba99f999">
<input name="name" placeholder="Your name" required><input name="phone" placeholder="Phone / WhatsApp" required><textarea name="message" placeholder="How can we help?" required></textarea><button class="btn">Send message</button></form></div></section>
</main>
<footer class="foot"><div class="wrap"><div class="cols">
<div><img class="flogo" src="/taprobane/assets/img/TAPROBANE-LOGO.png" alt="Cafe Taprobane" onerror="this.onerror=null;this.src='/taprobane/assets/img/logo.png'"><p>Authentic Sri Lankan food, from our kitchen to your table. අපේ කම දැනෙන වෙනස්ම රසයක්.</p>
<div class="soc"><a href="#" aria-label="Facebook">f</a><a href="#" aria-label="Instagram">ig</a><a href="#" aria-label="TikTok">tt</a></div></div>
<div><h4>Quick links</h4><a href="/taprobane/index.php">Home</a><a href="/taprobane/menu.php">Menus</a><a href="/taprobane/events.php">Lounge &amp; Events</a><a href="/taprobane/careers.php">Careers</a><a href="/taprobane/contact.php">Contact</a></div>
<div><h4>Contact us</h4><p><strong style="color:#fff">Al Nahda, Dubai</strong><br>050 428 6739 | 04 263 9079 | 04 296 7093</p><p><strong style="color:#fff">International City (City Branch)</strong><br>054 235 3364 | 04 552 8708</p><p>Open daily 7:00 AM - 2:00 AM</p></div>
<div><h4>Newsletter</h4><p>Stay updated with our latest offers and special events.</p><form class="nlf" id="nlForm"><input type="email" name="email" placeholder="Enter your email" required aria-label="Email"><input type="hidden" name="t" value="b773b880577ddb3a8c0d32a9ba99f999"><button>SUBSCRIBE</button></form><p id="nlMsg"></p></div>
</div><div class="copy"><span>© 2026 Dream S Media. All rights reserved.</span><span>Order on talabat · noon · deliveroo · careem · smiles</span></div></div></footer>

<div class="dock">
<a class="d wa" href="https://wa.me/971504286739" target="_blank" rel="noopener" aria-label="WhatsApp us"><svg viewBox="0 0 24 24"><path d="M12.04 2a9.9 9.9 0 0 0-8.5 15l-1.5 5.4 5.5-1.4A10 10 0 1 0 12.04 2zm5.8 14.1c-.25.7-1.4 1.3-1.95 1.35-.5.05-1.1.07-1.75-.1-.4-.1-.9-.3-1.6-.6-2.8-1.2-4.6-4-4.75-4.2-.14-.2-1.1-1.5-1.1-2.8s.7-2 .95-2.25c.25-.25.5-.3.7-.3h.5c.17 0 .4-.05.6.45.25.55.8 1.9.85 2.05.07.14.1.3 0 .5-.1.2-.15.3-.3.5-.15.15-.3.35-.45.5-.15.14-.3.3-.12.6.17.3.8 1.3 1.7 2.1 1.15 1 2.1 1.35 2.4 1.5.3.14.47.12.65-.07.17-.2.75-.87.95-1.17.2-.3.4-.25.65-.15.28.1 1.7.8 2 .95.3.15.5.22.57.35.07.12.07.7-.18 1.4z"/></svg></a>
<a class="d call" href="tel:+971504286739" aria-label="Call us"><svg viewBox="0 0 24 24"><path d="M6.6 10.8a15 15 0 0 0 6.6 6.6l2.2-2.2a1 1 0 0 1 1-.25 11 11 0 0 0 3.5.55 1 1 0 0 1 1 1V20a1 1 0 0 1-1 1A17 17 0 0 1 3 4a1 1 0 0 1 1-1h3.5a1 1 0 0 1 1 1c0 1.2.2 2.4.55 3.5a1 1 0 0 1-.25 1z"/></svg></a>
<button class="d chat" id="chatBtn" aria-label="Open chat"><svg viewBox="0 0 24 24"><path d="M4 4h16a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H9l-5 4v-4H4a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2z"/></svg></button></div>
<section class="chatbox" id="chatBox" hidden><header>Chat with Cafe Taprobane <button id="chatX" aria-label="Close">×</button></header>
<div id="chatLog"><p class="bot">Ayubowan! Send us a message and we will reply by phone or WhatsApp.</p></div>
<form id="chatForm"><input name="name" placeholder="Your name" required><input name="phone" placeholder="Phone / WhatsApp" required><textarea name="message" placeholder="Type your message" required></textarea><input type="hidden" name="t" value="b773b880577ddb3a8c0d32a9ba99f999"><button class="btn">Send message</button></form></section>
<script>window.BASE='/taprobane';</script><script src="/taprobane/assets/js/main.js"></script>
</body></html>