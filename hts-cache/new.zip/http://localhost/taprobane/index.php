<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Home | Cafe Taprobane - The Fusion Haven</title>
<meta name="description" content="Cafe Taprobane serves true Sri Lankan food across Dubai, Sharjah and Kandy. Cafe, lounge, bar and party events.">
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Anton&family=Outfit:wght@400;500;600;700&family=Inter:wght@400;500;600&family=Dancing+Script:wght@600&family=Noto+Sans+Sinhala:wght@500;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="/taprobane/assets/css/style.css"></head><body>
<header class="top"><div class="in">
<nav class="L" aria-label="Main"><a href="/taprobane/index.php" class="on">Home</a><a href="/taprobane/about.php" >About us</a><a href="/taprobane/branches.php" >Branches</a><a href="/taprobane/menu.php" >Menus</a></nav>
<a class="brand" href="/taprobane/index.php"><img class="" src="/taprobane/assets/img/TAPROBANE-LOGO.png" alt="Cafe Taprobane" onerror="this.onerror=null;this.src='/taprobane/assets/img/logo.png'"></a>
<nav class="R" aria-label="More"><a href="/taprobane/events.php" >Lounge &amp; Events</a><a href="/taprobane/news.php" >News</a><a href="/taprobane/careers.php" >Careers</a><a href="/taprobane/contact.php" >Contact</a></nav>
<button class="burger" aria-label="Menu" aria-expanded="false"><span></span><span></span><span></span></button>
<div class="drawer"><a href="/taprobane/index.php" class="on">Home</a><a href="/taprobane/about.php" >About us</a><a href="/taprobane/branches.php" >Branches</a><a href="/taprobane/menu.php" >Menus</a><a href="/taprobane/events.php" >Lounge &amp; Events</a><a href="/taprobane/news.php" >News</a><a href="/taprobane/careers.php" >Careers</a><a href="/taprobane/contact.php" >Contact</a></div></div></header><main>
<section class="hero" aria-roledescription="carousel" aria-label="Featured"><div class="wrap">
<div class="hs"><div class="slide on" role="group" aria-label="Slide 1 of 5"><div>
<span class="kick">Sri Lankan. Satisfying.</span><h1>GOOD FOOD, <span class="or">TRUE SPICE</span></h1><p class="lead">Fried fish, sausages, garlic and vegetables on our famous Bite Platter. Made fresh, delivered free.</p>
<div class="btns"><a class="btn" href="menu.php">View menu &rarr;</a><a class="btn ghost" href="https://wa.me/971504286739?text=Hi%20Cafe%20Taprobane%2C%20I%20would%20like%20to%20order." target="_blank" rel="noopener">Order on WhatsApp</a></div></div>
<div class="vis"><span class="splash"></span><img class="food" src="/taprobane/assets/img/slides/s1.png" alt="" ><div class="badge"><b>100%</b>True Sri Lankan spices</div></div></div>
<div class="slide " role="group" aria-label="Slide 2 of 5"><div>
<span class="kick">Every Monday</span><h1>KOTTHU, <span class="or">MADE FRESH</span></h1><p class="lead">Unlimited kotthu for AED 30 per person, 6 PM - 9 PM, dine-in at our International City branch.</p>
<div class="btns"><a class="btn" href="menu.php">See the menus &rarr;</a><a class="btn ghost" href="https://wa.me/971504286739?text=Hi%20Cafe%20Taprobane%2C%20I%20would%20like%20to%20order." target="_blank" rel="noopener">Order on WhatsApp</a></div></div>
<div class="vis"><span class="splash"></span><img class="food" src="/taprobane/assets/img/slides/s2.png" alt="" loading="lazy"><div class="badge"><b>100%</b>True Sri Lankan spices</div></div></div>
<div class="slide " role="group" aria-label="Slide 3 of 5"><div>
<span class="kick">Weekend special</span><h1>FAMILY <span class="or">COMBO</span></h1><p class="lead">Kulla, Double Rice Panittuwa, Sawala and Kapirinna Sawana. Made for the whole family.</p>
<div class="btns"><a class="btn" href="menu.php">View menu &rarr;</a><a class="btn ghost" href="https://wa.me/971504286739?text=Hi%20Cafe%20Taprobane%2C%20I%20would%20like%20to%20order." target="_blank" rel="noopener">Order on WhatsApp</a></div></div>
<div class="vis"><span class="splash"></span><img class="food" src="/taprobane/assets/img/slides/s3.png" alt="" loading="lazy"><div class="badge"><b>100%</b>True Sri Lankan spices</div></div></div>
<div class="slide " role="group" aria-label="Slide 4 of 5"><div>
<span class="kick">Every day, 11 AM - 3:30 PM</span><h1>LUNCH <span class="or">SET MENU</span></h1><p class="lead">Egg fried rice, chopsuey, deviled chicken and chilli paste at our City Branch.</p>
<div class="btns"><a class="btn" href="branches.php">Find a branch &rarr;</a><a class="btn ghost" href="https://wa.me/971504286739?text=Hi%20Cafe%20Taprobane%2C%20I%20would%20like%20to%20order." target="_blank" rel="noopener">Order on WhatsApp</a></div></div>
<div class="vis"><span class="splash"></span><img class="food" src="/taprobane/assets/img/slides/s4.png" alt="" loading="lazy"><div class="badge"><b>100%</b>True Sri Lankan spices</div></div></div>
<div class="slide " role="group" aria-label="Slide 5 of 5"><div>
<span class="kick">Opening soon</span><h1>ABU SHAGARA <span class="or">BRANCH</span></h1><p class="lead">A new Taprobane in Sharjah. The same true Sri Lankan taste, closer to you.</p>
<div class="btns"><a class="btn" href="branches.php">Our branches &rarr;</a><a class="btn ghost" href="https://wa.me/971504286739?text=Hi%20Cafe%20Taprobane%2C%20I%20would%20like%20to%20order." target="_blank" rel="noopener">Order on WhatsApp</a></div></div>
<div class="vis"><span class="splash"></span><img class="food" src="/taprobane/assets/img/slides/s5.png" alt="" loading="lazy"><div class="badge"><b>100%</b>True Sri Lankan spices</div></div></div>
</div>
<div class="hctl"><button class="arr2" data-d="-1" aria-label="Previous slide">&#8249;</button><div class="hdots"><button aria-label="Go to slide 1" class="on"></button><button aria-label="Go to slide 2" class=""></button><button aria-label="Go to slide 3" class=""></button><button aria-label="Go to slide 4" class=""></button><button aria-label="Go to slide 5" class=""></button></div><button class="arr2" data-d="1" aria-label="Next slide">&#8250;</button></div>
<div class="feats"><div class="feat"><span class="i"><svg viewBox="0 0 24 24"><path d="M3 13h2l1-5h9l2 5h3v4h-1.2a2.8 2.8 0 0 1-5.6 0H9.8a2.8 2.8 0 0 1-5.6 0H3z"/></svg></span><div><b>Free delivery</b><small>To where you are</small></div></div>
<div class="feat"><span class="i"><svg viewBox="0 0 24 24"><path d="M12 2l2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 16.9 6.1 20l1.2-6.5L2.5 8.9 9.1 8z"/></svg></span><div><b>True Sri Lankan taste</b><small>Real spices, every dish</small></div></div>
<div class="feat"><span class="i"><svg viewBox="0 0 24 24"><path d="M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zm1 5v5.4l4 2.4-.8 1.3-4.7-2.8V7z"/></svg></span><div><b>Open daily</b><small>7 AM - 2 AM (Dubai)</small></div></div></div>
</div></section>

<div class="mq" aria-hidden="true"><div><span>Kotthu <i>&#10059;</i></span><span>Rice &amp; Curry <i>&#10059;</i></span><span>Short Eats <i>&#10059;</i></span><span>Sizzling Grills <i>&#10059;</i></span><span>Fresh Juices <i>&#10059;</i></span><span>Chinese Corner <i>&#10059;</i></span><span>Family Combos <i>&#10059;</i></span><span>Party Platters <i>&#10059;</i></span><span>Kotthu <i>&#10059;</i></span><span>Rice &amp; Curry <i>&#10059;</i></span><span>Short Eats <i>&#10059;</i></span><span>Sizzling Grills <i>&#10059;</i></span><span>Fresh Juices <i>&#10059;</i></span><span>Chinese Corner <i>&#10059;</i></span><span>Family Combos <i>&#10059;</i></span><span>Party Platters <i>&#10059;</i></span><span>Kotthu <i>&#10059;</i></span><span>Rice &amp; Curry <i>&#10059;</i></span><span>Short Eats <i>&#10059;</i></span><span>Sizzling Grills <i>&#10059;</i></span><span>Fresh Juices <i>&#10059;</i></span><span>Chinese Corner <i>&#10059;</i></span><span>Family Combos <i>&#10059;</i></span><span>Party Platters <i>&#10059;</i></span><span>Kotthu <i>&#10059;</i></span><span>Rice &amp; Curry <i>&#10059;</i></span><span>Short Eats <i>&#10059;</i></span><span>Sizzling Grills <i>&#10059;</i></span><span>Fresh Juices <i>&#10059;</i></span><span>Chinese Corner <i>&#10059;</i></span><span>Family Combos <i>&#10059;</i></span><span>Party Platters <i>&#10059;</i></span></div></div>

<section class="sec"><div class="wrap"><div class="head rv"><div class="eyebrow c">Six corners, one kitchen</div><h2>Flavors of <span class="or">Taprobane</span></h2>
<p class="sub">From a plate of kotthu to a cold juice, pick your corner.</p></div>
<article class="row rv"><div class="n">01.</div>
<div><h3>Sri Lankan Corner</h3><div class="chips"><span>Kotthu</span><span>Kulla</span><span>Sawala</span><span>Rice &amp; curry</span></div><p>True Sri Lankan classics cooked with real spices.</p></div>
<div class="go"><a class="pill" href="menu.php">View menu</a><span class="circ">&rarr;</span></div></article><article class="row rv"><div class="n">02.</div>
<div><h3>Chinese Corner</h3><div class="chips"><span>Egg fried rice</span><span>Chopsuey</span><span>Devilled chicken</span><span>Noodles</span></div><p>Sri Lankan style Chinese favourites.</p></div>
<div class="go"><a class="pill" href="menu.php">View menu</a><span class="circ">&rarr;</span></div></article><article class="row rv"><div class="n">03.</div>
<div><h3>Indian Corner</h3><div class="chips"><span>Curries</span><span>Naan &amp; roti</span><span>Biriyani</span></div><p>Rich, slow cooked North and South Indian flavours.</p></div>
<div class="go"><a class="pill" href="menu.php">View menu</a><span class="circ">&rarr;</span></div></article><article class="row rv"><div class="n">04.</div>
<div><h3>Juice Corner</h3><div class="chips"><span>Fresh juices</span><span>Milkshakes</span><span>Iced drinks</span></div><p>Cold, fresh and made to order.</p></div>
<div class="go"><a class="pill" href="menu.php">View menu</a><span class="circ">&rarr;</span></div></article><article class="row rv"><div class="n">05.</div>
<div><h3>Grilled Corner</h3><div class="chips"><span>Grilled chicken</span><span>Kebabs</span><span>Grilled fish</span></div><p>Sizzling from the grill.</p></div>
<div class="go"><a class="pill" href="menu.php">View menu</a><span class="circ">&rarr;</span></div></article><article class="row rv"><div class="n">06.</div>
<div><h3>Snack Corner</h3><div class="chips"><span>Short eats</span><span>Rolls</span><span>Patties</span><span>Cutlets</span></div><p>Quick bites, fresh every morning.</p></div>
<div class="go"><a class="pill" href="menu.php">View menu</a><span class="circ">&rarr;</span></div></article></div></section>

<section class="sec band"><div class="wrap"><div class="head rv"><div class="eyebrow c">Chef's favorites</div><h2>Taprobane <span class="or">Delights</span></h2>
<p class="sub">Our most loved plates and platters. Order in one tap on WhatsApp.</p></div>
<div class="grid" style="grid-template-columns:repeat(auto-fit,minmax(290px,1fr))"><article class="card dl rv"><div class="imgw"><img src="/taprobane/assets/img/dishes/buffet.jpg" alt="Unlimited Dinner Buffet" loading="lazy"></div><div class="b"><span class="tag">Chef's pick</span><h3>Unlimited Dinner Buffet</h3><p>Chicken kotthu, indiappa kotthu and daiyya kotthu, as much as you like.</p>
<div class="foot2"><span class="pr"></span><a class="pill" target="_blank" rel="noopener" href="https://wa.me/971504286739?text=Hi%20Cafe%20Taprobane%2C%20I%20would%20like%20to%20order%3A%20Unlimited%20Dinner%20Buffet">Order now</a></div></div></article><article class="card dl rv"><div class="imgw"><img src="/taprobane/assets/img/dishes/chopsuey.jpg" alt="Sizzling Shawl Chopsuey" loading="lazy"></div><div class="b"><span class="tag">Chef's pick</span><h3>Sizzling Shawl Chopsuey</h3><p>Stir-fried vegetables and sauce, served sizzling hot.</p>
<div class="foot2"><span class="pr"></span><a class="pill" target="_blank" rel="noopener" href="https://wa.me/971504286739?text=Hi%20Cafe%20Taprobane%2C%20I%20would%20like%20to%20order%3A%20Sizzling%20Shawl%20Chopsuey">Order now</a></div></div></article><article class="card dl rv"><div class="imgw"><img src="/taprobane/assets/img/dishes/sawala.jpg" alt="Kapirinna Sawan 4 Pax" loading="lazy"></div><div class="b"><span class="tag">Chef's pick</span><h3>Kapirinna Sawan 4 Pax</h3><p>A big sharing platter with rice, egg, sausages and more, for four people.</p>
<div class="foot2"><span class="pr"></span><a class="pill" target="_blank" rel="noopener" href="https://wa.me/971504286739?text=Hi%20Cafe%20Taprobane%2C%20I%20would%20like%20to%20order%3A%20Kapirinna%20Sawan%204%20Pax">Order now</a></div></div></article><article class="card dl rv"><div class="imgw"><img src="/taprobane/assets/img/dishes/cheese-kotthu.jpg" alt="Cheese Kotthu" loading="lazy"></div><div class="b"><span class="tag">Chef's pick</span><h3>Cheese Kotthu</h3><p>Chopped godamba roti tossed with vegetables, spices and melted cheese.</p>
<div class="foot2"><span class="pr"></span><a class="pill" target="_blank" rel="noopener" href="https://wa.me/971504286739?text=Hi%20Cafe%20Taprobane%2C%20I%20would%20like%20to%20order%3A%20Cheese%20Kotthu">Order now</a></div></div></article><article class="card dl rv"><div class="imgw"><img src="/taprobane/assets/img/dishes/daiyya-kotthu.jpg" alt="Daiyya Kotthu" loading="lazy"></div><div class="b"><span class="tag">Chef's pick</span><h3>Daiyya Kotthu</h3><p>Our fiery, dark-roasted kotthu with chilli and spring onion.</p>
<div class="foot2"><span class="pr"></span><a class="pill" target="_blank" rel="noopener" href="https://wa.me/971504286739?text=Hi%20Cafe%20Taprobane%2C%20I%20would%20like%20to%20order%3A%20Daiyya%20Kotthu">Order now</a></div></div></article><article class="card dl rv"><div class="imgw"><img src="/taprobane/assets/img/dishes/bite-platter.jpg" alt="Bite Platter" loading="lazy"></div><div class="b"><span class="tag">Chef's pick</span><h3>Bite Platter</h3><p>Fried fish, sausages, garlic, vegetables and fruit for sharing.</p>
<div class="foot2"><span class="pr"></span><a class="pill" target="_blank" rel="noopener" href="https://wa.me/971504286739?text=Hi%20Cafe%20Taprobane%2C%20I%20would%20like%20to%20order%3A%20Bite%20Platter">Order now</a></div></div></article></div>
<p style="text-align:center;margin-top:2rem"><a class="btn ghost" href="menu.php">View full menu &rarr;</a></p></div></section>

<section class="sec"><div class="wrap story"><div class="rv"><div class="eyebrow">Our story</div><h2>Passion in <span class="or">Every Plate</span></h2>
<p class="sub" style="margin-top:1rem">Taprobane is the old name of Sri Lanka. Every kitchen cooks the same recipes with true Sri Lankan spices, from Dubai to Kandy.</p>
<div class="script">Cafe Taprobane</div>
<div class="stats"><div><b>5</b><small>Branches</small></div><div><b>2</b><small>Countries</small></div><div><b>Free</b><small>Delivery</small></div></div>
<p style="margin-top:1.6rem"><a class="btn ghost" href="about.php">Read our story</a></p></div>
<div class="collage rv"><img src="/taprobane/assets/img/story-main.jpg" alt="Cafe Taprobane Sharjah dining room" loading="lazy"><img src="/taprobane/assets/img/story-2.jpg" alt="Bite platter" loading="lazy"><img src="/taprobane/assets/img/story-3.jpg" alt="Family combo" loading="lazy"></div></div></section>

<section class="sec band"><div class="wrap"><div style="display:flex;justify-content:space-between;align-items:end;flex-wrap:wrap;gap:1rem;margin-bottom:1.8rem">
<div><div class="eyebrow">What's new</div><h2>Specials &amp; <span class="or">News</span></h2></div><a class="btn ghost" href="news.php">All news &rarr;</a></div>
<div class="car"><button class="arr l" aria-label="Previous">&#8249;</button><div class="track"><article class="card"><h3>Unlimited Kotthu every Monday</h3><p>Chicken Indiappa Kotthu, Chicken Kotthu and Chicken Daiyya Kotthu, as much as you can eat for AED 30 per person. Monday 6 PM - 9 PM, dine-in only, ...</p><hr><small class="or">4 Oct 2026</small></article><article class="card"><h3>Everyday lunch set menu</h3><p>Egg fried rice, chopsuey, deviled chicken and chilli paste, every day 11 AM - 3:30 PM at the City Branch.</p><hr><small class="or">4 Oct 2026</small></article><article class="card"><h3>Family Combo</h3><p>Kulla, Double Rice Panittuwa, Sawala, Thachchiya and Kapirinna Sawana, made for the whole family. Free delivery to where you are.</p><hr><small class="or">4 Oct 2026</small></article></div>
<button class="arr r" aria-label="Next">&#8250;</button></div><div class="dots"></div></div></section>

<section class="sec"><div class="wrap"><div class="head rv"><div class="eyebrow c">Find us</div><h2>Our <span class="or">Branches</span></h2></div>
<div class="grid"><article class="card rv"><span class="tag ">Open now</span>
<h3>Al Nahda, Dubai</h3><p>Al Nahda 1, Dubai</p><p><a href="branches.php#al-nahda">Details</a> · <a href="menu.php?b=al-nahda">Menu</a></p></article><article class="card rv"><span class="tag ">Open now</span>
<h3>International City (City Branch)</h3><p>France Cluster, Building P22, International City, Dubai</p><p><a href="branches.php#international-city">Details</a> · <a href="menu.php?b=international-city">Menu</a></p></article><article class="card rv"><span class="tag soon">Opening soon</span>
<h3>Sharjah - Al Qulayaah</h3><p>Shop 01, Al Qulayaah, Sharjah</p><p><a href="branches.php#sharjah">Details</a> · <a href="menu.php?b=sharjah">Menu</a></p></article><article class="card rv"><span class="tag soon">Opening soon</span>
<h3>Abu Shagara, Sharjah</h3><p>Abu Shagara, Sharjah</p><p><a href="branches.php#abu-shagara">Details</a> · <a href="menu.php?b=abu-shagara">Menu</a></p></article><article class="card rv"><span class="tag ">Open now</span>
<h3>Taprobane Lounge, Kandy</h3><p>Kandy, Sri Lanka</p><p><a href="branches.php#kandy-lounge">Details</a> · <a href="menu.php?b=kandy-lounge">Menu</a></p></article></div></div></section>

<section class="sec cta"><div class="wrap rv"><h2>Hungry? We deliver free.</h2><p>Call, WhatsApp, or order on talabat, noon, deliveroo, careem and smiles.</p>
<div class="btns" style="justify-content:center"><a class="btn" href="https://wa.me/971504286739?text=Hi%20Cafe%20Taprobane%2C%20I%20would%20like%20to%20order." target="_blank" rel="noopener">Order on WhatsApp</a><a class="btn" href="tel:+971504286739">Call now</a></div></div></section>
</main>
<footer class="foot"><div class="wrap"><div class="cols">
<div><img class="flogo" src="/taprobane/assets/img/TAPROBANE-LOGO.png" alt="Cafe Taprobane" onerror="this.onerror=null;this.src='/taprobane/assets/img/logo.png'"><p>Authentic Sri Lankan food, from our kitchen to your table. අපේ කම දැනෙන වෙනස්ම රසයක්.</p>
<div class="soc"><a href="#" aria-label="Facebook">f</a><a href="#" aria-label="Instagram">ig</a><a href="#" aria-label="TikTok">tt</a></div></div>
<div><h4>Quick links</h4><a href="/taprobane/index.php">Home</a><a href="/taprobane/menu.php">Menus</a><a href="/taprobane/events.php">Lounge &amp; Events</a><a href="/taprobane/careers.php">Careers</a><a href="/taprobane/contact.php">Contact</a></div>
<div><h4>Contact us</h4><p><strong style="color:#fff">Al Nahda, Dubai</strong><br>050 428 6739 | 04 263 9079 | 04 296 7093</p><p><strong style="color:#fff">International City (City Branch)</strong><br>054 235 3364 | 04 552 8708</p><p>Open daily 7:00 AM - 2:00 AM</p></div>
<div><h4>Newsletter</h4><p>Stay updated with our latest offers and special events.</p><form class="nlf" id="nlForm"><input type="email" name="email" placeholder="Enter your email" required aria-label="Email"><input type="hidden" name="t" value="b773b880577ddb3a8c0d32a9ba99f999"><button>SUBSCRIBE</button></form><p id="nlMsg"></p></div>
</div><div class="copy"><span>© 2026 Dream S Media. All rights reserved.</span><span>Order on talabat · noon · deliveroo · careem · smiles</span></div></div></footer>

<div class="dock">
<a class="d wa" href="https://wa.me/971504286739" target="_blank" rel="noopener" aria-label="WhatsApp us"><svg viewBox="0 0 24 24"><path d="M12.04 2a9.9 9.9 0 0 0-8.5 15l-1.5 5.4 5.5-1.4A10 10 0 1 0 12.04 2zm5.8 14.1c-.25.7-1.4 1.3-1.95 1.35-.5.05-1.1.07-1.75-.1-.4-.1-.9-.3-1.6-.6-2.8-1.2-4.6-4-4.75-4.2-.14-.2-1.1-1.5-1.1-2.8s.7-2 .95-2.25c.25-.25.5-.3.7-.3h.5c.17 0 .4-.05.6.45.25.55.8 1.9.85 2.05.07.14.1.3 0 .5-.1.2-.15.3-.3.5-.15.15-.3.35-.45.5-.15.14-.3.3-.12.6.17.3.8 1.3 1.7 2.1 1.15 1 2.1 1.35 2.4 1.5.3.14.47.12.65-.07.17-.2.75-.87.95-1.17.2-.3.4-.25.65-.15.28.1 1.7.8 2 .95.3.15.5.22.57.35.07.12.07.7-.18 1.4z"/></svg></a>
<a class="d call" href="tel:+971504286739" aria-label="Call us"><svg viewBox="0 0 24 24"><path d="M6.6 10.8a15 15 0 0 0 6.6 6.6l2.2-2.2a1 1 0 0 1 1-.25 11 11 0 0 0 3.5.55 1 1 0 0 1 1 1V20a1 1 0 0 1-1 1A17 17 0 0 1 3 4a1 1 0 0 1 1-1h3.5a1 1 0 0 1 1 1c0 1.2.2 2.4.55 3.5a1 1 0 0 1-.25 1z"/></svg></a>
<button class="d chat" id="chatBtn" aria-label="Open chat"><svg viewBox="0 0 24 24"><path d="M4 4h16a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H9l-5 4v-4H4a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2z"/></svg></button></div>
<section class="chatbox" id="chatBox" hidden><header>Chat with Cafe Taprobane <button id="chatX" aria-label="Close">×</button></header>
<div id="chatLog"><p class="bot">Ayubowan! Send us a message and we will reply by phone or WhatsApp.</p></div>
<form id="chatForm"><input name="name" placeholder="Your name" required><input name="phone" placeholder="Phone / WhatsApp" required><textarea name="message" placeholder="Type your message" required></textarea><input type="hidden" name="t" value="b773b880577ddb3a8c0d32a9ba99f999"><button class="btn">Send message</button></form></section>
<script>window.BASE='/taprobane';</script><script src="/taprobane/assets/js/main.js"></script>
</body></html>